Download datasets from the google drive links and place them in this directory. Your directory structure should look something like this
  
  `Synthetic_Rain_Datasets` <br/>
  `├──`[train](https://drive.google.com/drive/folders/1Hnnlc5kI0v9_BtfMytC2LR5VpLAFZtVe?usp=sharing)  <br/>
  `└──`[test](https://drive.google.com/drive/folders/1PDWggNh8ylevFmrjo-JEvlmqsDlWWvZs?usp=sharing)  <br/>
      `├──Test100`   <br/>
      `├──Rain100H`  <br/>
      `├──Rain100L`  <br/>
      `├──Test1200`  <br/>
      `└──Test2800`
