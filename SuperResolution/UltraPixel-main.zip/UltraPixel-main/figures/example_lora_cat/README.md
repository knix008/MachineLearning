example dataset for lora personalization
