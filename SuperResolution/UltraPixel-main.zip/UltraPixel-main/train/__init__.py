from .train_b import WurstCore as WurstCoreB
from .train_c import WurstCore as WurstCoreC
from .train_t2i import WurstCore as WurstCore_t2i
from .train_ultrapixel_control import WurstCore as WurstCore_control_lrguide
from .train_personalized import WurstCore as WurstCore_personalized